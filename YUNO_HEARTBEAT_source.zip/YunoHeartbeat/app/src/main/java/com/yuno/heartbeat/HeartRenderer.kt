package com.yuno.heartbeat

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.BlurMaskFilter
import kotlin.math.cos
import kotlin.math.sin
import kotlin.random.Random

object HeartRenderer {
    fun render(context: Context, color: Int, bass: Float, mids: Float, highs: Float, frame: Int): Bitmap {
        val size = 440
        val bitmap = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(bitmap)
        canvas.drawColor(Color.TRANSPARENT)
        val pulse = 1f + bass.coerceIn(0f, 1f) * 0.13f + 0.018f * sin(frame * 0.22f)
        val path = heartPath(size / 2f, size / 2f, 8.2f * pulse, bass, mids, highs, frame)

        val glow = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            style = Paint.Style.STROKE
            strokeWidth = 13f + bass * 8f
            strokeJoin = Paint.Join.ROUND
            strokeCap = Paint.Cap.ROUND
            color = color
            alpha = 125
            maskFilter = BlurMaskFilter(23f + bass * 10f, BlurMaskFilter.Blur.NORMAL)
        }
        canvas.drawPath(path, glow)

        val core = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            style = Paint.Style.STROKE
            strokeWidth = 5.5f + mids * 2f
            strokeJoin = Paint.Join.ROUND
            strokeCap = Paint.Cap.ROUND
            this.color = color
            alpha = 245
        }
        canvas.drawPath(path, core)

        val inner = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            style = Paint.Style.STROKE
            strokeWidth = 1.6f
            color = Color.WHITE
            alpha = (45 + highs * 95).toInt().coerceIn(0, 150)
        }
        canvas.drawPath(path, inner)

        // Short horizontal digital tears: restrained at rest, stronger on transients.
        val glitchPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            style = Paint.Style.STROKE
            strokeWidth = 2f
            color = color
            alpha = (35 + highs * 150 + bass * 35).toInt().coerceIn(0, 220)
        }
        val random = Random(frame / 2 + 71)
        val count = 2 + (highs * 9).toInt()
        repeat(count) {
            val y = random.nextInt(115, 340).toFloat()
            val half = random.nextInt(12, 62).toFloat()
            val shift = random.nextInt(-14, 15).toFloat() * (0.3f + highs)
            canvas.drawLine(size / 2f - half + shift, y, size / 2f + half + shift, y, glitchPaint)
        }

        // A few tiny sparks around the silhouette.
        val spark = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = color; alpha = (60 + highs * 150).toInt().coerceIn(0, 210) }
        repeat((2 + highs * 8).toInt()) {
            val x = random.nextInt(55, size - 55).toFloat()
            val y = random.nextInt(55, size - 55).toFloat()
            canvas.drawCircle(x, y, random.nextFloat() * 2.2f + 0.7f, spark)
        }
        return bitmap
    }

    private fun heartPath(cx: Float, cy: Float, scale: Float, bass: Float, mids: Float, highs: Float, frame: Int): Path {
        val path = Path()
        val points = 180
        for (i in 0..points) {
            val t = (i.toFloat() / points) * (Math.PI * 2.0).toFloat()
            val baseX = 16f * sin(t).let { it * it * it }
            val baseY = 13f * cos(t) - 5f * cos(2f * t) - 2f * cos(3f * t) - cos(4f * t)
            val wobble = 1f + bass * 0.055f * sin(3f * t + frame * 0.18f) + mids * 0.025f * sin(9f * t - frame * 0.13f)
            val glitch = if (highs > 0.12f && (i + frame) % 37 < 3) highs * 0.10f else 0f
            val x = cx + baseX * scale * (wobble + glitch)
            val y = cy - baseY * scale * (wobble - glitch)
            if (i == 0) path.moveTo(x, y) else path.lineTo(x, y)
        }
        path.close()
        return path
    }
}
