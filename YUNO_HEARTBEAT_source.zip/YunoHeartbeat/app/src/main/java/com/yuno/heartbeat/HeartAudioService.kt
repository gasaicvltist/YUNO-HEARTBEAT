package com.yuno.heartbeat

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.media.audiofx.Visualizer
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import androidx.core.app.NotificationCompat
import kotlin.math.sqrt

class HeartAudioService : Service() {
    private val handler = Handler(Looper.getMainLooper())
    private var visualizer: Visualizer? = null
    private var bass = 0.10f
    private var mids = 0.08f
    private var highs = 0.05f
    private var frame = 0
    private val tick = object : Runnable {
        override fun run() {
            frame++
            HeartWidgetProvider.updateAll(this@HeartAudioService, bass, mids, highs, frame)
            handler.postDelayed(this, 450L)
        }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            stopSelf()
            return START_NOT_STICKY
        }
        startForeground(NOTIFICATION_ID, buildNotification())
        startCapture()
        handler.removeCallbacks(tick)
        handler.post(tick)
        return START_STICKY
    }

    private fun startCapture() {
        try {
            visualizer?.release()
            visualizer = Visualizer(0).apply {
                captureSize = Visualizer.getCaptureSizeRange()[1]
                setDataCaptureListener(object : Visualizer.OnDataCaptureListener {
                    override fun onWaveFormDataCapture(v: Visualizer?, waveform: ByteArray?, samplingRate: Int) {
                        if (waveform != null && waveform.isNotEmpty()) {
                            var sum = 0.0
                            waveform.forEach { sum += ((it.toInt() and 0xFF) - 128).let { n -> n * n }.toDouble() }
                            val rms = sqrt(sum / waveform.size) / 128.0
                            bass = smooth(bass, (rms * 1.7).toFloat())
                        }
                    }
                    override fun onFftDataCapture(v: Visualizer?, fft: ByteArray?, samplingRate: Int) {
                        if (fft != null && fft.size > 16) {
                            fun band(from: Int, to: Int): Float {
                                var total = 0.0; var count = 0
                                for (i in from until minOf(to, fft.size / 2)) {
                                    val re = fft[2 * i].toInt(); val im = fft[2 * i + 1].toInt()
                                    total += sqrt((re * re + im * im).toDouble()); count++
                                }
                                return if (count == 0) 0f else (total / count / 42.0).toFloat().coerceIn(0f, 1f)
                            }
                            bass = smooth(bass, band(1, 8))
                            mids = smooth(mids, band(8, 35))
                            highs = smooth(highs, band(35, 100))
                        }
                    }
                }, Visualizer.getMaxCaptureRate() / 2, true, true)
                enabled = true
            }
        } catch (_: Exception) {
            // Some Android builds or playback apps do not expose the global output mix.
            bass = 0.12f; mids = 0.08f; highs = 0.05f
        }
    }

    private fun smooth(old: Float, next: Float): Float = (old * 0.68f + next.coerceIn(0f, 1f) * 0.32f).coerceIn(0f, 1f)

    private fun buildNotification(): Notification {
        val channelId = "yuno_heartbeat_audio"
        if (Build.VERSION.SDK_INT >= 26) {
            val channel = NotificationChannel(channelId, "YUNO HEARTBEAT", NotificationManager.IMPORTANCE_LOW)
            getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
        }
        val stop = PendingIntent.getService(this, 1, Intent(this, HeartAudioService::class.java).setAction(ACTION_STOP),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        return NotificationCompat.Builder(this, channelId)
            .setSmallIcon(android.R.drawable.ic_media_play)
            .setContentTitle("YUNO HEARTBEAT")
            .setContentText("Музыкальное сердцебиение активно")
            .setOngoing(true)
            .addAction(android.R.drawable.ic_media_pause, "Остановить", stop)
            .build()
    }

    override fun onDestroy() {
        handler.removeCallbacks(tick)
        try { visualizer?.enabled = false; visualizer?.release() } catch (_: Exception) {}
        visualizer = null
        HeartWidgetProvider.updateAll(this)
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null

    companion object {
        const val ACTION_STOP = "com.yuno.heartbeat.STOP"
        private const val NOTIFICATION_ID = 42
    }
}
