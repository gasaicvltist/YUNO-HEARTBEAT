package com.yuno.heartbeat

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.os.Build
import android.os.Bundle
import android.view.Gravity
import android.view.ViewGroup
import android.widget.Button
import android.widget.LinearLayout
import android.widget.SeekBar
import android.widget.TextView
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat

class MainActivity : Activity() {
    private var red = 255
    private var green = 45
    private var blue = 134
    private lateinit var preview: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val prefs = getSharedPreferences("yuno", MODE_PRIVATE)
        val saved = prefs.getInt("heart_color", 0xFFFF2D86.toInt())
        red = Color.red(saved); green = Color.green(saved); blue = Color.blue(saved)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(28, 36, 28, 24)
            setBackgroundColor(Color.rgb(12, 10, 16))
        }
        fun label(text: String, size: Float = 16f) = TextView(this).apply {
            this.text = text; textSize = size; setTextColor(Color.WHITE)
            setPadding(0, 12, 0, 8)
        }
        root.addView(label("YUNO HEARTBEAT", 25f))
        root.addView(label("Неоновое сердце · компактный виджет", 14f))
        preview = label("●  Цвет свечения", 16f)
        root.addView(preview)
        addColorSlider(root, "Красный", red) { red = it; saveColor() }
        addColorSlider(root, "Зелёный", green) { green = it; saveColor() }
        addColorSlider(root, "Синий", blue) { blue = it; saveColor() }

        val start = Button(this).apply {
            text = "Включить реакцию на музыку"
            setOnClickListener { requestAudioAndStart() }
        }
        root.addView(start, matchWidth())
        val stop = Button(this).apply {
            text = "Остановить"
            setOnClickListener { stopService(Intent(this@MainActivity, HeartAudioService::class.java)) }
        }
        root.addView(stop, matchWidth())
        root.addView(label("После установки: удерживай главный экран → Виджеты → YUNO HEARTBEAT. Добавь виджет размером примерно 2×2.", 13f))
        root.addView(label("Для реакции на звук Android попросит разрешение на микрофон. Некоторые приложения могут ограничивать передачу аудио визуализатору.", 12f))
        setContentView(root)
    }

    private fun addColorSlider(root: LinearLayout, title: String, initial: Int, changed: (Int) -> Unit) {
        val row = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        row.addView(TextView(this).apply { text = title; setTextColor(Color.LTGRAY) })
        val bar = SeekBar(this).apply {
            max = 255; progress = initial
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(seekBar: SeekBar?, value: Int, fromUser: Boolean) { if (fromUser) changed(value) }
                override fun onStartTrackingTouch(seekBar: SeekBar?) {}
                override fun onStopTrackingTouch(seekBar: SeekBar?) {}
            })
        }
        row.addView(bar)
        root.addView(row, matchWidth())
    }

    private fun saveColor() {
        val color = Color.rgb(red, green, blue)
        getSharedPreferences("yuno", MODE_PRIVATE).edit().putInt("heart_color", color).apply()
        preview.setTextColor(color)
        HeartWidgetProvider.updateAll(this)
    }

    private fun requestAudioAndStart() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.RECORD_AUDIO), 10)
        } else startAudioService()
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, results: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, results)
        if (requestCode == 10 && results.isNotEmpty() && results[0] == PackageManager.PERMISSION_GRANTED) startAudioService()
    }

    private fun startAudioService() {
        val intent = Intent(this, HeartAudioService::class.java)
        if (Build.VERSION.SDK_INT >= 26) ContextCompat.startForegroundService(this, intent) else startService(intent)
    }

    private fun matchWidth() = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
}
