package com.yuno.heartbeat

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.widget.RemoteViews

class HeartWidgetProvider : AppWidgetProvider() {
    override fun onUpdate(context: Context, manager: AppWidgetManager, ids: IntArray) {
        ids.forEach { updateOne(context, manager, it) }
    }

    companion object {
        fun updateAll(context: Context, bass: Float = 0.12f, mids: Float = 0.08f, highs: Float = 0.05f, frame: Int = 0) {
            val manager = AppWidgetManager.getInstance(context)
            val ids = manager.getAppWidgetIds(ComponentName(context, HeartWidgetProvider::class.java))
            ids.forEach { updateOne(context, manager, it, bass, mids, highs, frame) }
        }

        private fun updateOne(context: Context, manager: AppWidgetManager, id: Int,
                              bass: Float = 0.12f, mids: Float = 0.08f, highs: Float = 0.05f, frame: Int = 0) {
            val prefs = context.getSharedPreferences("yuno", Context.MODE_PRIVATE)
            val color = prefs.getInt("heart_color", 0xFFFF2D86.toInt())
            val views = RemoteViews(context.packageName, R.layout.heart_widget)
            views.setImageViewBitmap(R.id.heart_image, HeartRenderer.render(context, color, bass, mids, highs, frame))
            val open = PendingIntent.getActivity(context, 0, Intent(context, MainActivity::class.java),
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
            views.setOnClickPendingIntent(R.id.heart_image, open)
            manager.updateAppWidget(id, views)
        }
    }
}
